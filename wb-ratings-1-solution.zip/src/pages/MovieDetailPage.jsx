export default function MovieDetailPage() {
  return (
    <>
      <h1>Movie Detail Page</h1>
      <p>TODO</p>
    </>
  );
}
