export default function AllMoviesPage() {
  return (
    <>
      <h1>All Movies</h1>
      <p>TODO</p>
    </>
  );
}
